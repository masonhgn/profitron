from typing import Dict
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

'''
this gets the stats of a specific set of returns so we can plug this into backtesting
'''

class PerformanceStats:

    @staticmethod
    def compute(initial_capital: float, pnl_series: pd.Series) -> Dict[str, float]:

        returns = pnl_series.diff().dropna() / initial_capital

        sharpe = returns.mean() / returns.std() * np.sqrt(252) if returns.std() > 0 else 0.0
        drawdown = (pnl_series - pnl_series.cummax()) / pnl_series.cummax()
        drawdown = drawdown.replace([np.inf, -np.inf], np.nan).dropna()
        max_dd = drawdown.min()
        total_return = pnl_series.iloc[-1] - pnl_series.iloc[0] if not pnl_series.empty else 0.0


        return {
            "total_return": total_return,
            "sharpe_ratio": sharpe,
            "max_drawdown": max_dd,
            "return_std": returns.std(),
            "avg_daily_return": returns.mean()
        }
    
    @staticmethod
    def plot(pnl_series: pd.Series, title: str = "Strategy Performance", save_path: str = "performance_plot2.png"):
        if pnl_series.empty:
            print("[PerformanceStats] Cannot plot: PnL series is empty.")
            return

        drawdown = (pnl_series - pnl_series.cummax()) / (pnl_series.cummax() + 1e-8)

        fig, ax = plt.subplots(2, 1, figsize=(12, 8), sharex=True)

        ax[0].plot(pnl_series.index, pnl_series.values, label="Cumulative PnL")
        ax[0].set_ylabel("PnL ($)")
        ax[0].set_title(title)
        ax[0].legend()
        ax[0].grid(True)

        ax[1].fill_between(drawdown.index, drawdown.values, color='red', alpha=0.3, label="Drawdown")
        ax[1].set_ylabel("Drawdown (%)")
        ax[1].set_xlabel("Date")
        ax[1].legend()
        ax[1].grid(True)

        plt.tight_layout()
        plt.savefig(save_path)
        print(f"[PerformanceStats] Plot saved to {save_path}")