# src/backtesting/Backtester.py

from typing import List, Dict
from dataclasses import dataclass
import pandas as pd
import numpy as np
from tqdm import tqdm

from portfolio.PortfolioManager import PortfolioManager
from strategy.TradingStrategy import TradingStrategy
from .PerformanceStats import PerformanceStats
from signals.Signal import Signal


@dataclass
class BacktestConfig:
    start_date: str
    end_date: str
    capital: float
    slippage_bps: float
    commission_per_trade: float
    rebalance_frequency: str = "daily"


def combine_signals(signals: List[Signal], all_assets: List[str], max_gross_exposure: float = 1.0) -> pd.Series:

    asset_to_column = {name.replace("_close", ""): name for name in all_assets}
    weights = pd.Series(0.0, index=all_assets)

    for sig in signals:
        pct = sig.target_pct or 0.0
        column_name = asset_to_column.get(sig.symbol)
        if column_name is None:
            print(f"Warning: Signal symbol {sig.symbol} does not match any data column")
            continue
        if sig.action == "buy":
            weights[column_name] += pct
        elif sig.action == "sell":
            weights[column_name] -= pct

    # normalize total gross exposure to max_gross_exposure
    gross = weights.abs().sum()
    if gross > max_gross_exposure:
        weights *= max_gross_exposure / gross

    return weights.clip(-1.0, 1.0)

class Backtester:
    def __init__(self, strategies: List[TradingStrategy], price_data: pd.DataFrame, config: BacktestConfig):
        self.strategies = strategies
        self.data = price_data
        self.config = config
        self.pm = PortfolioManager(config.capital)

        self.config.start_date = pd.Timestamp(self.config.start_date)
        self.config.end_date = pd.Timestamp(self.config.end_date)

    def run(self) -> Dict[str, pd.DataFrame]:
        date_index = self.data.index
        positions = pd.DataFrame(index=date_index, columns=self.data.columns, dtype=float).fillna(0)
        pnl = pd.Series(index=date_index, dtype=float)

        for t, date in tqdm(enumerate(date_index), total=len(date_index), desc="Backtesting"):
            if date < self.config.start_date or date > self.config.end_date:
                continue

            day_prices = self.data.loc[date]

            #1 collect all signals from all strategies
            all_signals: List[Signal] = []
            for strat in self.strategies:
                signals = strat.generate_signals(self.data.loc[:date])
                all_signals.extend(signals)

            #2 convert to unified target weights
            signal_sum = combine_signals(all_signals, self.data.columns.tolist(), max_gross_exposure=1.0)

            #3 apply slippage to simulate execution
            # use only close prices for trading
            if isinstance(day_prices.index, pd.MultiIndex):
                try:
                    close_prices = day_prices.loc[(slice(None), "close")]
                    close_prices.index = close_prices.index.droplevel(1)  # drop "close" level
                except KeyError:
                    raise ValueError("[Backtester] 'close' prices not found in MultiIndex day_prices!")
            else:
                close_prices = day_prices  # assume it's already flat, with columns like ["BTC-USDT", "ETH-USDT"]


            slippage = (self.config.slippage_bps / 10000) * close_prices.abs()
            effective_price = close_prices + np.sign(signal_sum) * slippage

            #4 position sizing
            current_position = self.pm.update_positions(signal_sum, effective_price)

            #5 mark-to-market PnL 
            trading_cost = self.config.commission_per_trade * signal_sum.abs().sum()

            if t > 0:
                price_diff = close_prices - self.data.loc[self.data.index[t-1]]
                daily_pnl = (positions.iloc[t-1] * price_diff).sum() - trading_cost
                pnl[date] = daily_pnl

            positions.loc[date] = current_position

            # print(f"Date: {date}")
            # print(f"Signals: {all_signals}")
            # print(f"Position: {positions.iloc[t - 1].to_dict()}")


        cumulative_pnl = pnl.dropna().cumsum()
        results = {
            "pnl": cumulative_pnl,
            "positions": positions,
            "stats": PerformanceStats.compute(self.config.capital, cumulative_pnl)
        }
        print(cumulative_pnl.to_string())
        PerformanceStats.plot(cumulative_pnl, title="My Cool Strategy")
        return results
