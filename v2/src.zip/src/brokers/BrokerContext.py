# src/brokers/BrokerContext.py

from typing import Dict, Any
from portfolio.LivePortfolio import LivePortfolio
from signals.Signal import Signal
from execution.OrderManager import OrderManager
import ccxt


class BrokerContext:
    def __init__(self, name: str, config: Dict[str, Any]):
        self.name = name
        self.config = config
        self.mode = config.get("mode", "paper")
        self.api = self._init_api()
        self.portfolio = LivePortfolio(starting_cash=config.get("starting_cash", 100_000))
        self.order_manager = OrderManager(self.api, timeout=config.get("order_timeout", 30))

    def _init_api(self):
        if self.mode == "paper":
            return None  
        if self.name == "binanceus":
            return ccxt.binanceus({
                'apiKey': self.config.get("api_key", ""),
                'secret': self.config.get("api_secret", ""),
                'enableRateLimit': True
            })
        raise ValueError(f"[BrokerContext] unsupported broker: {self.name}")

    def sync(self):
        """syncs live portfolio data from broker"""
        if self.mode == "paper" or self.api is None:
            return  #we don't have to sync shit with paper trading

        balance = self.api.fetch_balance()
        cash = balance.get("USDT", {}).get("free", 0.0)

        positions = {}
        for asset, amount in balance["total"].items():
            if amount > 0:
                symbol = asset + "-USDT"  # normalize to internal naming
                positions[symbol] = {
                    "units": amount,
                    "avg_cost": 0.0  # placeholder unless tracked or derived
                }

        self.portfolio.sync_from_api(positions, cash)

    def place_order(self, signal: Signal):
        """executes or queues the order based on signal metadata"""
        if self.mode == "paper":
            print(f"[PAPER] {signal.action.upper()} {signal.symbol} x {signal.quantity or signal.target_pct}")
            return

        if signal.order_type == "market":
            self._place_market_order(signal)
        elif signal.order_type == "limit":
            self.order_manager.submit_order(signal)
        else:
            print(f"[WARN] Unsupported order type: {signal.order_type}")

    def _place_market_order(self, signal: Signal):
        market_symbol = signal.symbol.replace("-", "/")
        side = "buy" if signal.action == "buy" else "sell"
        quantity = signal.quantity or self._infer_quantity(signal)

        try:
            self.api.create_market_order(symbol=market_symbol, side=side, amount=quantity)
            print(f"[LIVE] MARKET {side.upper()} {market_symbol} x{quantity}")
        except Exception as e:
            print(f"[ERROR] failed to place market order: {e}")

    def _infer_quantity(self, signal: Signal) -> float:
        price = self.api.fetch_ticker(signal.symbol.replace("-", "/"))["last"]
        capital = self.config.get("default_trade_size", 100)
        return round(capital / price, 8)  # we want as many decimals as possible
