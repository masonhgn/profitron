import time
from typing import Dict, Optional
from signals.Signal import Signal


class OrderManager:
    def __init__(self, client, timeout: int = 30):
        """
        Args:
            client: broker client object (e.g., ccxt)
            timeout: seconds before canceling a stale order
        """
        self.client = client
        self.timeout = timeout
        self.open_orders: Dict[str, Dict] = {}  # order_id -> {signal, time, status}

    def submit_order(self, signal: Signal) -> Optional[str]:

        try:
            symbol = signal.symbol.replace("-", "/")
            side = "buy" if signal.action == "buy" else "sell"
            quantity = signal.quantity or self._infer_quantity(signal)
            limit_price = signal.meta.get("limit_price")

            order = self.client.create_limit_order(symbol, side, quantity, limit_price)

            self.open_orders[order["id"]] = {
                "signal": signal,
                "timestamp": time.time(),
                "status": "open"
            }

            print(f"[OrderManager] submitted LIMIT {side.upper()} {symbol} x{quantity} @ {limit_price}")
            return order["id"]

        except Exception as e:
            print(f"[OrderManager] failed to submit order: {e}")
            return None











    def _infer_quantity(self, signal: Signal) -> float:
        ticker = self.client.fetch_ticker(signal.symbol.replace("-", "/"))
        price = ticker["last"]
        capital = signal.target_pct * 10000 if signal.target_pct else 100  # fallback
        return round(capital / price, 8)

    def check_and_cancel_stale_orders(self):
        """check if an order is older than timeout, cancel if so"""
        now = time.time()
        to_cancel = []

        for order_id, meta in self.open_orders.items():
            age = now - meta["timestamp"]
            if age > self.timeout and meta["status"] == "open":
                to_cancel.append(order_id)

        for oid in to_cancel:
            try:
                self.client.cancel_order(oid)
                print(f"[OrderManager] canceled stale order: {oid}")
                signal = self.open_orders[oid]["signal"]

                if signal.meta.get("replace_with_market", False):
                    self._replace_with_market(signal)

                self.open_orders[oid]["status"] = "cancelled"
            except Exception as e:
                print(f"[OrderManager] failed to cancel order {oid}: {e}")

    def _replace_with_market(self, signal: Signal):
        try:
            symbol = signal.symbol.replace("-", "/")

            side = "buy" if signal.action == "buy" else "sell"

            quantity = signal.quantity or self._infer_quantity(signal)



            self.client.create_market_order(symbol, side, quantity)
            
            print(f"[OrderManager] replaced with MARKET {side.upper()} {symbol} x{quantity}")
        except Exception as e:
            print(f"[OrderManager] failed to replace with market order: {e}")
