# src/execution/Executor.py

from typing import Dict, Any, Callable, List
from signals.SignalMonitor import SignalMonitor
from signals.Signal import Signal
import ccxt


class Executor:
    def __init__(self, monitor: SignalMonitor, config: Dict[str, Any]):
        self.monitor = monitor
        self.config = config
        self.mode = config.get("mode", "paper")  # "paper" or "live"

        if self.mode == "live":
            self.client = ccxt.binanceus({
                'apiKey': config.get("api_key", ""),
                'secret': config.get("api_secret", ""),
                'enableRateLimit': True
            })
        else:
            self.client = None  # paper mode simulation

        # Dispatch table for asset_type handling
        self.dispatch: Dict[str, Callable[[Signal], None]] = {
            "crypto": self._handle_crypto,
            "equity": self._handle_equity,
            "option": self._handle_option
        }

    def execute(self):
        signals: List[Signal] = self.monitor.run_once()
        print(f"[Executor] {len(signals)} signals received.")

        for sig in signals:
            handler = self.dispatch.get(sig.asset_type, self._handle_default)
            handler(sig)

    def _handle_crypto(self, sig: Signal):
        size = self._determine_size(sig)
        market_symbol = sig.symbol.replace("-", "/")

        if self.mode == "live":
            try:
                print(f"[LIVE] Placing {sig.action.upper()} order for {market_symbol} (${size:.2f})")
                # self.client.create_market_order(...)
            except Exception as e:
                print(f"[ERROR] Failed to place crypto order: {e}")
        else:
            print(f"[PAPER] {sig.action.upper()} {market_symbol} | Size: ${size:.2f}")

    def _handle_equity(self, sig: Signal):
        size = self._determine_size(sig)
        if self.mode == "live":
            print(f"[LIVE] (Equity) {sig.action.upper()} {sig.symbol} (${size:.2f})")
            # Add real broker API here
        else:
            print(f"[PAPER] (Equity) {sig.action.upper()} {sig.symbol} | Size: ${size:.2f}")

    def _handle_option(self, sig: Signal):
        size = self._determine_size(sig)
        details = sig.meta.get("limit_price", "market")
        print(f"[{self.mode.upper()}] OPTION {sig.action.upper()} {sig.symbol} x{sig.quantity or '?'} @ {details}")

    def _handle_default(self, sig: Signal):
        print(f"[Executor] Unknown asset type '{sig.asset_type}' — skipping signal: {sig}")

    def _determine_size(self, sig: Signal) -> float:
        """calculate trade size in dollars or quantity, depending on context"""
        if sig.quantity:
            return sig.quantity  # exact quantity takes priority
        elif sig.target_pct:
            return sig.target_pct * self.config.get("paper_capital", 10000)
        else:
            return self.config.get("fixed_size", 100.0)
