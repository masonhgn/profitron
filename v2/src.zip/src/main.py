# main.py

import argparse
import sys
import traceback
from core.Engine import Engine


def main():
    parser = argparse.ArgumentParser(description="Trading Engine")
    parser.add_argument(
        "--config",
        type=str,
        default="src/core/config/Engine.yaml",
        help="Path to system config YAML file"
    )

    args = parser.parse_args()

    try:
        engine = Engine(config_path=args.config)
        engine.run()

    except KeyboardInterrupt:
        print("\n[main] Interrupted by user. Shutting down gracefully.")

    except Exception as e:
        print(f"[main] FATAL ERROR: {e}")
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
