# src/strategy/CointegrationStrategy.py

from dataclasses import dataclass
import pandas as pd
import numpy as np
import statsmodels.api as sm
from typing import List, Dict
from ...TradingStrategy import TradingStrategy
from signals.Signal import Signal
import os

@dataclass
class CointegrationStrategy(TradingStrategy):
    """
    see explore.ipynb
    """
    asset_1: Dict[str, str]  # {'symbol': 'ETH', 'type': 'crypto'}
    asset_2: Dict[str, str]
    lookback: int
    entry_z: float
    exit_z: float
    frequency: str = "1h"
    poll_interval: int = 60
    fields: List[str] = None
    hedge_ratio_method: str = "ols"

    def get_assets(self) -> List[Dict[str, str]]:
        return [self.asset_1, self.asset_2]

    def get_frequency(self) -> str:
        return self.frequency

    def get_lookback_window(self) -> int:
        return self.lookback

    def get_fields(self) -> List[str]:
        return self.fields or ["close"]

    def get_poll_interval(self) -> int:
        return self.poll_interval


    def generate_signals(self, data: pd.DataFrame) -> List[Signal]:
        """
        generate trade signals based on z-score of the cointegration spread

        Args:
            data (pd.DataFrame): Price data with columns [asset_1, asset_2]

        Returns:
            List[Signal]: List of Signal objects (latest signal only)
        """


        sym_1 = self.asset_1["symbol"]
        sym_2 = self.asset_2["symbol"]
        col_1 = f"{sym_1}_close"
        col_2 = f"{sym_2}_close"

        if col_1 not in data.columns or col_2 not in data.columns:
            raise ValueError(f"missing close columns: {col_1}, {col_2}")

        close_data = data[[col_1, col_2]].copy()
        close_data.columns = ["asset_1", "asset_2"]  # rename to asset names for internal use
        #close_data = close_data.resample("1D").ffill()
        if len(close_data) <= self.lookback:
            return []

        log_data = np.log(close_data)
        t = len(log_data) - 1
        window = log_data.iloc[t - self.lookback:t]

        y = window["asset_1"].dropna()
        x = window["asset_2"].dropna()


        if hasattr(self, "hedge_ratio_method") and self.hedge_ratio_method == "ols":
            x_const = sm.add_constant(x)


            model = sm.OLS(y, x_const).fit()
            hedge_ratio = model.params.iloc[1]
        else:
            raise NotImplementedError("Only OLS hedge ratio is implemented!")

        spread = log_data.iloc[t]["asset_1"] - hedge_ratio * log_data.iloc[t]["asset_2"]
        spread_series = y - hedge_ratio * x



        spread_std = spread_series.std()
        if np.isnan(spread_std) or spread_std == 0:
            print(f"[Z-score] Cannot compute z-score — std={spread_std}")
            return []

        zscore = (spread - spread_series.mean()) / spread_std
        zscore = float(zscore)



        signals: List[Signal] = []


        base_weight = 0.5  # max allocation per leg

        # higher z -> higher conviction
        z_multiplier = min(abs(zscore) / self.entry_z, 2.0)  # cap multiplier at 2x

        #higher vol -> smaller position
        vol_multiplier = 1.0 / spread_std if spread_std > 0 else 1.0
        vol_multiplier = min(vol_multiplier, 5.0)  # avoid going too crazy if vol is tiny

        target_pct = base_weight * z_multiplier * vol_multiplier
        target_pct = np.clip(target_pct, 0.0, 1.0)  # safety cap



        if zscore > self.entry_z:
            signals.append(Signal(symbol=sym_1, action="sell", target_pct=target_pct, asset_type=self.asset_1["type"]))
            signals.append(Signal(symbol=sym_2, action="buy", target_pct=target_pct, asset_type=self.asset_2["type"]))
        elif zscore < -self.entry_z:
            signals.append(Signal(symbol=sym_1, action="buy", target_pct=target_pct, asset_type=self.asset_1["type"]))
            signals.append(Signal(symbol=sym_2, action="sell", target_pct=target_pct, asset_type=self.asset_2["type"]))
        elif abs(zscore) < self.exit_z:
            signals.append(Signal(symbol=sym_1, action="sell", target_pct=0.0, asset_type=self.asset_1["type"]))
            signals.append(Signal(symbol=sym_2, action="sell", target_pct=0.0, asset_type=self.asset_2["type"]))

        #print(f"[Z-score] {zscore:.2f} | Entry: {self.entry_z} | Exit: {self.exit_z}")
        return signals