# src/strategy/TradingStrategy.py

from abc import ABC, abstractmethod
from typing import List
import pandas as pd
from signals.Signal import Signal


class TradingStrategy(ABC):
    """parent class for strats"""

    @abstractmethod
    def generate_signals(self, data: pd.DataFrame) -> List[Signal]:
        """
        Generate a list of Signal objects based on historical data.

        Args:
            data (pd.DataFrame): Time-indexed price data for relevant assets.

        Returns:
            List[Signal]: Structured trade signals (long, short, etc.)
        """
        pass
