
#src/utils.py



import yaml
from typing import Dict, Any


def load_yaml_config(path: str) -> Dict[str, Any]:
    """
    loads a yaml config to be passed into a dataclass constructor
    """
    with open(path, 'r') as f:
        return yaml.safe_load(f)