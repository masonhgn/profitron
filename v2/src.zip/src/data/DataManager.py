# src/data/DataManager.py

from typing import Dict, Any, List
from utils import load_yaml_config
import pandas as pd
from data.sources.BinanceUSSource import BinanceUSSource
from data.sources.AlpacaSource import AlpacaSource
from data.sources.LocalFileSource import LocalFileSource
from .DataSource import DataSource
from collections import defaultdict


class DataManager:
    def __init__(self, config_path: str):
        self.config_path = config_path
        self.config = load_yaml_config(config_path)
        self.sources: Dict[str, DataSource] = {}
        self._initialize_sources()





    def get_available_frequencies(self, source_name: str, symbol: str) -> List[str]:
        source = self._get_source(source_name)
        if not hasattr(source, "get_available_frequencies"):
            raise NotImplementedError(f"Source '{source_name}' does not support frequency introspection!!")
        return source.get_available_frequencies(symbol)



    def _initialize_sources(self):
        for name, cfg in self.config.get("data_sources", {}).items():
            source_type = cfg.get("type")

            if source_type == "binanceus":
                self.sources[name] = BinanceUSSource(cfg)
            elif source_type == "localfile":
                self.sources[name] = LocalFileSource(cfg)
            elif source_type == "alpaca":
                self.sources[name] = AlpacaSource(cfg)
            else:
                raise ValueError(f"unsupported data source type: {source_type}")







    def get_price_data(
        self,
        assets: List[Dict[str, str]],
        start_date: str,
        end_date: str,
        frequency: str = "1d",
        fields: List[str] = ["close"]
    ) -> pd.DataFrame:
        if frequency != "1d":
            raise ValueError('get_price_data() NOT SUPPORTED FOR < 1d FREQUENCY!!!')
            
        grouped = defaultdict(list)
        for asset in assets:
            grouped[asset["type"]].append(asset["symbol"])

        combined = []
        for asset_type, symbols in grouped.items():
            source_name = self._get_source_for_type(asset_type)
            source = self._get_source('alpaca')
            df = source.get_price_data(symbols, start_date, end_date, asset_type, frequency, fields)

            if df.empty:
                raise ValueError(
                    f"[DataManager] No data returned for {symbols} ({asset_type}) "
                    f"from {start_date} to {end_date} at frequency '{frequency}'"
                )
    
            
            # Convert timestamp index to date only (drop time component)
            df.index = df.index.date
            
            # If there are duplicate dates after dropping the time, keep the last value for each date
            df = df.groupby(level=0).last()
            
            combined.append(df)

        # Use merge for combining the dataframes instead of concat
        if combined:
            final_df = combined[0]
            for i in range(1, len(combined)):
                final_df = pd.merge(
                    final_df, 
                    combined[i], 
                    left_index=True, 
                    right_index=True, 
                    how='outer'
                )
        else:
            final_df = pd.DataFrame()
        
        # Sort the result by date
        final_df = final_df.sort_index().dropna()
        final_df.index = pd.to_datetime(final_df.index).map(
            lambda x: x.replace(hour=17, minute=0, second=0)
        )
        final_df.to_csv('test_data.csv')

        if final_df.empty:
            raise ValueError("[DataManager] combined price data is empty — check assets or time range!")

        print("[DataManager] Combined data:")

        return final_df
        







    def _get_source_for_type(self, asset_type: str) -> str:
        if asset_type == "crypto":
            return "binance_us"
        elif asset_type == "equity":
            return "alpaca"
        else:
            raise ValueError(f"Unsupported asset type: {asset_type}")




    #USE FOR LATER WHEN WE NEED MORE DATA SOURCES (POSSIBLE HIGH FREQUENCY?)
    def get_price_data_with_fallback(
        self,
        primary: str,
        fallback: str,
        symbols: List[str],
        start_date: str,
        end_date: str,
        frequency: str = "1d",
        fields: List[str] = ["close"],
        write_back: bool = True
    ) -> pd.DataFrame:
        try:
            return self.get_price_data(primary, symbols, start_date, end_date, frequency, fields)
        except FileNotFoundError as e:
            print(f"[WARN] primary source '{primary}' missing data, falling back to '{fallback}'...")

            df = self.get_price_data(fallback, symbols, start_date, end_date, frequency, fields)

            if write_back:
                for symbol in symbols:
                    symbol_df = df[symbol].copy() if isinstance(df.columns, pd.MultiIndex) else df.filter(like=symbol).copy()
                    symbol_df["datetime"] = symbol_df.index
                    self.store_price_data(primary, symbol, symbol_df, frequency)

            return df







    def get_live_price(self, source_name: str, symbol: str) -> float:
        source = self._get_source(source_name)
        return source.get_live_price(symbol)

    def store_price_data(
        self,
        source_name: str,
        symbol: str,
        df: Any,
        frequency: str = "1d"
    ):
        """store price data into local source (e.g. LocalFileSource)"""
        source = self._get_source(source_name)

        if not hasattr(source, "store_price_data"):
            raise NotImplementedError(f"source {source_name} does not support storing data..")

        source.store_price_data(symbol, df, frequency)





    def sync_data_from_to(
        self,
        from_source: str,
        to_source: str,
        symbols: List[str],
        start_date: str,
        end_date: str,
        frequency: str = "1d"
    ):
        """pulls data from a remote source (e.g. Binance) and stores it locally"""
        df = self.get_price_data(from_source, symbols, start_date, end_date, frequency)
        for symbol in symbols:
            # If multi-indexed by symbol, extract single symbol
            if isinstance(df.columns, pd.MultiIndex):
                sub_df = df[symbol].copy()
            else:
                sub_df = df.filter(like=symbol).copy()
                sub_df.columns = [col.replace(f"{symbol}_", "") for col in sub_df.columns]

            sub_df["datetime"] = sub_df.index
            self.store_price_data(to_source, symbol, sub_df, frequency)






    def _get_source(self, name: str) -> DataSource:
        if name not in self.sources:
            raise KeyError(f"data source '{name}' is not initialized!!")
        return self.sources[name]



