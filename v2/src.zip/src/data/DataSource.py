from abc import ABC, abstractmethod
from typing import List, Dict, Any
import pandas as pd
import numpy as np




class DataSource(ABC):

    @abstractmethod
    def get_price_data(
        self, 
        symbols: List[str], 
        start_date: str, 
        end_date: str, 
        frequency: str = "1d", 
        fields: List[str] = ["close"]
    ) -> pd.DataFrame:
        """returns a multi-index DataFrame: (date, symbol) with selected price fields e.g. OHLCV or only 'close'"""

    def get_live_price(self, symbol: str) -> float:
        """
        Real-time price quote
        """

    def get_order_book(self, symbol: str, depth: int = 10) -> Dict[str, Any]:
        """
        Level 2 market depth, bids/asks
        """

    def get_fundamentals(self, symbol: str, fields: List[str]) -> Dict[str, Any]:
        """
        Get company or token fundamentals
        """

    def get_events(self, symbol: str, event_type: str = "splits") -> pd.DataFrame:
        """
        Corporate actions, dividend schedule, etc.
        """

    def get_volatility(self, symbol: str, lookback: int = 30) -> float:
        """
        Realized vol over N days
        """

    def get_returns(
            self,
            symbol: str,
            start_date: str,
            end_date: str,
            frequency: str = "1d",
            log: bool = False
        ) -> pd.Series:
            """return time series of returns for an asset.

            Returns:
                Series of returns.
            """
            price_df = self.get_price_data([symbol], start_date, end_date, frequency, fields=["close"])
            prices = price_df[symbol]["close"] if isinstance(price_df.columns, pd.MultiIndex) else price_df["close"]


            if log:
                returns = (prices / prices.shift(1)).apply(lambda x: np.log(x))
            else:
                returns = prices.pct_change()

            return returns.dropna()

    def resample_data(self, df: pd.DataFrame, frequency: str = "1d", method: str = "ohlc") -> pd.DataFrame:
        """
        resample raw data to a new frequency

        Args:
            df (pd.DataFrame): Raw time-indexed data (OHLCV or close only)
            frequency (str): Desired frequency (e.g., '1h', '1d', '1w')
            method (str): Resampling method. Default = 'ohlc'. Other options:
                - 'mean' for averages
                - 'last' for last observed value
                - 'sum' for volume resampling, etc.

        Returns:
            pd.DataFrame: Resampled data
        """
        if method == "ohlc":
            return df.resample(frequency).ohlc()
        elif method == "mean":
            return df.resample(frequency).mean()
        elif method == "sum":
            return df.resample(frequency).sum()
        elif method == "last":
            return df.resample(frequency).last()
        else:
            raise ValueError(f"Unsupported resampling method: {method}")


    def get_available_frequencies(self, symbol: str) -> List[str]:
        """
        return a list of available frequencies for a symbol.
        Default: not implemented.
        """
        raise NotImplementedError("This source does not support frequency introspection.")