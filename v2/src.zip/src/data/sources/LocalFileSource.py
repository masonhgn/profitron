# src/data/sources/LocalFileSource.py

import os
import pandas as pd
import pyarrow.parquet as pq
import pyarrow as pa
import duckdb
from typing import List, Dict, Any
from ..DataSource import DataSource


class LocalFileSource(DataSource):
    def __init__(self, config: Dict[str, Any]):
        self.base_path = config.get("path", "data/")
        self.format = config.get("format", "parquet")  # parquet or csv
        self.use_duckdb = config.get("use_duckdb", False)

        os.makedirs(self.base_path, exist_ok=True)

        if self.use_duckdb:
            self.con = duckdb.connect(database=':memory:')


    def get_available_frequencies(self, symbol: str) -> List[str]:
        """lists available frequencies for a given symbol (checks folder structure)"""
        freqs = []
        for freq_dir in os.listdir(self.base_path):
            full_path = os.path.join(self.base_path, freq_dir, f"{symbol}.{self.format}")
            if os.path.exists(full_path):
                freqs.append(freq_dir)
        return freqs




    def get_price_data(
        self,
        symbols: List[str],
        start_date: str,
        end_date: str,
        frequency: str = "1d",
        fields: List[str] = ["close"]
    ) -> pd.DataFrame:
        dfs = []

        for symbol in symbols:
            path = os.path.join(self.base_path, frequency, f"{symbol}.{self.format}")

            if not os.path.exists(path):
                raise FileNotFoundError(f"data file not found: {path}")

            df = pd.read_parquet(path) if self.format == "parquet" else pd.read_csv(path, parse_dates=["datetime"], index_col="datetime")
            df = df.loc[start_date:end_date]

            if fields != ["*"]:
                df = df[fields]

            dfs.append(df.rename(columns=lambda col: f"{symbol}_{col}"))

        return pd.concat(dfs, axis=1)







    def store_price_data(self, symbol: str, df: pd.DataFrame, frequency: str = "1d") -> None:
        df = df.copy()
        df["datetime"] = pd.to_datetime(df["datetime"])
        df.index = pd.to_datetime(df.index)
        df.set_index("datetime", inplace=True)
        df.sort_index(inplace=True)

        symbol_dir = os.path.join(self.base_path, frequency)
        os.makedirs(symbol_dir, exist_ok=True)

        path = os.path.join(symbol_dir, f"{symbol}.{self.format}")

        if os.path.exists(path):
            existing = pd.read_parquet(path) if self.format == "parquet" else pd.read_csv(path, parse_dates=["datetime"], index_col="datetime")
            combined = pd.concat([existing, df])
            combined = combined[~combined.index.duplicated(keep="last")]
        else:
            combined = df

        combined.sort_index(inplace=True)

        if self.format == "parquet":
            pq.write_table(pa.Table.from_pandas(combined), path)
        else:
            combined.to_csv(path)
