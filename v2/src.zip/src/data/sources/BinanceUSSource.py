# src/data/sources/BinanceUSSource.py

import ccxt
import pandas as pd
from datetime import datetime
from typing import List, Dict, Any
from ..DataSource import DataSource


class BinanceUSSource(DataSource):
    def __init__(self, config: Dict[str, Any]):
        self.client = ccxt.binanceus({
            'apiKey': config.get("api_key", ""),
            'secret': config.get("api_secret", ""),
            'enableRateLimit': True
        })
        self.max_limit = 1000  # binance US allows 1000 candles per request
        self.timeframe_map = {
            "1m": "1m",
            "5m": "5m",
            "15m": "15m",
            "1h": "1h",
            "4h": "4h",
            "1d": "1d"
        }

    def get_price_data(
        self,
        symbols: List[str],
        start_date: str,
        end_date: str,
        frequency: str = "1d",
        fields: List[str] = ["close"]
    ) -> pd.DataFrame:
        df_list = []
        for symbol in symbols:
            market_symbol = symbol.replace("-", "/").upper()
            df = self._fetch_symbol_data(market_symbol, start_date, end_date, frequency)
            df = df[fields]  
            df.columns = [f"{symbol}_{col}" for col in df.columns] 
            df_list.append(df)

        combined_df = pd.concat(df_list, axis=1)
        return combined_df

    def _fetch_symbol_data(self, symbol: str, start: str, end: str, frequency: str) -> pd.DataFrame:
        since = self.client.parse8601(pd.to_datetime(start).isoformat())
        end_ts = pd.to_datetime(end)

        all_candles = []
        timeframe = self.timeframe_map.get(frequency)
        if not timeframe:
            raise ValueError(f"Unsupported frequency: {frequency}")

        while True:
            candles = self.client.fetch_ohlcv(symbol, timeframe=timeframe, since=since, limit=self.max_limit)
            if not candles:
                break

            df = pd.DataFrame(candles, columns=["timestamp", "open", "high", "low", "close", "volume"])
            df["datetime"] = pd.to_datetime(df["timestamp"], unit="ms")
            df.set_index("datetime", inplace=True)
            df.drop("timestamp", axis=1, inplace=True)

            all_candles.append(df)
            since = candles[-1][0] + 1

            if pd.to_datetime(since, unit="ms") > end_ts:
                break

        full_df = pd.concat(all_candles)
        full_df = full_df.loc[start:end]
        return full_df

    def get_live_price(self, symbol: str) -> float:
        market_symbol = symbol.replace("-", "/").upper()
        ticker = self.client.fetch_ticker(market_symbol)
        return ticker["last"]
