import pandas as pd
from datetime import datetime
from typing import List, Dict, Any
from alpaca.data.historical import StockHistoricalDataClient, CryptoHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, CryptoBarsRequest
from alpaca.data.enums import Adjustment
from alpaca.data.timeframe import TimeFrame
from ..DataSource import DataSource


class AlpacaSource(DataSource):
    def __init__(self, config: Dict[str, Any]):
        self.api_key = config.get("api_key")
        self.api_secret = config.get("api_secret")

        self.stock_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        self.crypto_client = CryptoHistoricalDataClient(self.api_key, self.api_secret)

        self.freq_map = {
            "1m": TimeFrame.Minute,
            "5m": TimeFrame(5, TimeFrame.Minute),
            "15m": TimeFrame(15, TimeFrame.Minute),
            "1h": TimeFrame.Hour,
            "1d": TimeFrame.Day
        }

    def get_price_data(
        self,
        symbols: List[str],
        start_date: str,
        end_date: str,
        asset_type: str,
        frequency: str = "1d",
        fields: List[str] = ["close"]
    ) -> pd.DataFrame:
        if asset_type == 'equity':
            return self.get_equity_price_data(symbols,start_date,end_date,frequency,fields)
        elif asset_type == 'crypto':
            return self.get_crypto_price_data(symbols,start_date,end_date,frequency,fields)


    def get_equity_price_data(
        self,
        symbols: List[str],
        start_date: str,
        end_date: str,
        frequency: str = "1d",
        fields: List[str] = ["close"]
    ) -> pd.DataFrame:
        timeframe = self.freq_map.get(frequency)
        if not timeframe:
            raise ValueError(f"Unsupported frequency: {frequency}")

        request = StockBarsRequest(
            symbol_or_symbols=symbols,
            start=pd.to_datetime(start_date),
            end=pd.to_datetime(end_date),
            timeframe=timeframe,
            adjustment=Adjustment.ALL
        )

        barset = self.stock_client.get_stock_bars(request).df
        print(f"[AlpacaSource] Equity data date range: {barset.index.min()} to {barset.index.max()}")
        if not isinstance(barset, pd.DataFrame) or barset.empty:
            print(f"[AlpacaSource] Empty equity data for: {symbols}")
            return pd.DataFrame()

        if isinstance(barset.index, pd.MultiIndex):
            barset = barset.reset_index()

        barset["timestamp"] = pd.to_datetime(barset["timestamp"]).dt.tz_localize(None)
        barset.set_index("timestamp", inplace=True)

        data_dict = {
            sym: group[fields].add_prefix(f"{sym}_")
            for sym, group in barset.groupby("symbol")
        }

        return pd.concat(data_dict.values(), axis=1)







    def get_crypto_price_data(
        self,
        symbols: List[str],
        start_date: str,
        end_date: str,
        frequency: str = "1d",
        fields: List[str] = ["close"]
    ) -> pd.DataFrame:
        timeframe = self.freq_map.get(frequency)
        if not timeframe:
            raise ValueError(f"Unsupported frequency: {frequency}")

        request = CryptoBarsRequest(
            symbol_or_symbols=symbols,
            start=pd.to_datetime(start_date),
            end=pd.to_datetime(end_date),
            timeframe=timeframe
        )

        barset = self.crypto_client.get_crypto_bars(request).df
        print(f"[AlpacaSource] Equity data date range: {barset.index.min()} to {barset.index.max()}")
        if not isinstance(barset, pd.DataFrame) or barset.empty:
            print(f"[AlpacaSource] Empty crypto data for: {symbols}")
            return pd.DataFrame()

        if isinstance(barset.index, pd.MultiIndex):
            barset = barset.reset_index()

        barset["timestamp"] = pd.to_datetime(barset["timestamp"]).dt.tz_localize(None)
        barset.set_index("timestamp", inplace=True)

        data_dict = {
            sym: group[fields].add_prefix(f"{sym}_")
            for sym, group in barset.groupby("symbol")
        }

        return pd.concat(data_dict.values(), axis=1)




