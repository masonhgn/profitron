# src/core/Engine.py

import time
from typing import Dict, Any
import pandas as pd
from backtest.Backtester import Backtester, BacktestConfig
from signals.SignalMonitor import SignalMonitor
from portfolio.MetaPortfolio import MetaPortfolio
from brokers.BrokerContext import BrokerContext
from strategy.TradingStrategy import TradingStrategy
from data.DataManager import DataManager
from utils import load_yaml_config


class Engine:
    def __init__(self, config_path: str):
        self.config = load_yaml_config(config_path)
        self.mode = self.config.get("mode", "paper")  # live or paper or backtest
        self.meta = MetaPortfolio()
        self.data_manager = DataManager(config_path=self.config["monitor"]["data_manager_config"])
        self._init_brokers()
        self.strategy = self._init_strategy()
        self.monitor = self._init_monitor()

        if self.mode == "backtest":
            self.backtester = self._init_backtester()

    def _init_brokers(self):
        brokers_cfg = self.config.get("brokers", {})
        for name, broker_cfg in brokers_cfg.items():
            ctx = BrokerContext(name, broker_cfg)
            self.meta.register_broker(name, ctx)

    def _init_strategy(self) -> TradingStrategy:
        strat_cfg = self.config["strategy"]
        module = __import__(strat_cfg["module"], fromlist=[strat_cfg["class"]])
        strat_class = getattr(module, strat_cfg["class"])
        return strat_class(**strat_cfg["params"])

    def _init_monitor(self) -> SignalMonitor:
        mon_cfg = self.config["monitor"]
        dm_config_path = mon_cfg["data_manager_config"]
        data_manager = DataManager(config_path=dm_config_path)

        monitor_config = {
            "frequency": self.strategy.get_frequency(),
            "fields": self.strategy.get_fields(),
            "lookback_window": self.strategy.get_lookback_window(),
            "poll_interval": self.strategy.get_poll_interval(),
            "data_manager_config": dm_config_path
        }

        return SignalMonitor(
            strategy=self.strategy,
            data_manager=data_manager,
            config=monitor_config
        )
    
    def _init_backtester(self) -> Backtester:
        bt_cfg = self.config["backtest"]
        bt_config = BacktestConfig(**bt_cfg["params"])

        assets = self.strategy.get_assets()  # [{'symbol': 'ETH', 'type': 'crypto'}, ...]
        frequency = self.strategy.get_frequency()
        fields = self.strategy.get_fields()

        data = self.data_manager.get_price_data(

            assets=assets,
            start_date=bt_config.start_date,
            end_date=bt_config.end_date,
            frequency=frequency,
            fields=fields
        )

        return Backtester(
            strategies=[self.strategy],
            price_data=data,
            config=bt_config
        )

    def run(self):
        print(f"[Engine] running in {self.mode.upper()} mode..")
        if self.mode == "backtest":
            self._run_backtest()
        else:
            self._run_live_or_paper()

    def _run_backtest(self):
        results = self.backtester.run()
        print("[Engine] backtest complete!!! summary:")
        print(results["stats"])
        return results

    def _run_live_or_paper(self):
        poll_interval = self.strategy.get_poll_interval()
        while True:
            try:
                self.meta.sync_all()
                signals = self.monitor.run_once()
                for sig in signals:
                    self.meta.place_order(sig)

                if self.config.get("print_summary", True):
                    prices = self._get_price_lookup(signals)
                    summary = self.meta.summary(prices)
                    print(f"[Engine] Summary:\n{summary}")
            except Exception as e:
                print(f"[Engine] Error: {e}")

            time.sleep(poll_interval)

    def _get_price_lookup(self, signals) -> Dict[str, float]:
        """extract latest prices for symbols in the signals for reporting"""
        prices = {}
        for sig in signals:
            broker = self.meta.brokers.get(self.meta._select_broker(sig).name)
            if broker and broker.api:
                try:
                    ticker = broker.api.fetch_ticker(sig.symbol.replace("-", "/"))
                    prices[sig.symbol] = ticker["last"]
                except:
                    prices[sig.symbol] = 0.0
        return prices
